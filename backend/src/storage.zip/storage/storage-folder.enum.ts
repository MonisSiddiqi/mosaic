export enum StorageFolderEnum {
  USERS = 'users',
  PROJECTS = 'projects',
  SERVICES = 'services',
}
